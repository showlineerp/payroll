<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TerminationType extends Model
{
	protected $fillable = [
		'termination_title','employee_id'
	];


}
